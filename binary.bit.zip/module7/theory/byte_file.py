with open('binary.bit', 'wb') as fh:
    fh.write(b'Kari')
    print(fh)