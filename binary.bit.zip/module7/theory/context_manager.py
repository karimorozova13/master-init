with open('test.txt', 'w+') as fh:
    print(33)