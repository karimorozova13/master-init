# tuples as keys
points = {
    (0,0): 'O',
    (1,1): "A",
    (2,2): "B"
}
print(points)
# we can't modify the tuple

# tuple with one value
tuple1 = ('S',)
print(tuple1)
