import math

print(math.sqrt(-1))
print('Hi there')
print('Commit from VS')
_new_var = 30
x = 8**3 + 4*(2 + 2)
print(x)
# user_age = 7
user_age = 18 # it's adult for younger
int_number = 3 #type int
float_num = 3.3 # type float
complex_num =3.3 + 2j # type complex
name = "Kari"
live = 'lives'
here= 'here'

joined_str= f"{name} {live} {here}" # concatenation
print(joined_str)
# a= input('Add some text: ')
# print(a)

#age = input('Your age is: ') #output type is string
#age = int(age) # convert to number, int
float_number= float('3.3') # convert float str to float num
string = str(5.2) # convert to str whatever


a = -2
b = 7
c = -6
D =b**2 - 4 * a * c
B = 49 -48
x1 = math.sqrt((-7 + 1**0.5) / (2* -2))
# x2 = (math.sqrt(-b - D**0.5) / (2*a))
print(math.radians(0.1275))