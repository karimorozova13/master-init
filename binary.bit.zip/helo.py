def say_hello(user):
    print(f'Hello {user}')
def main():
    print('you are importing hello.py')
    say_hello()

if __name__ == '__main__':
    main()
